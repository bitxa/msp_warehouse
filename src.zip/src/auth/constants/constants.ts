// constants.ts
export const jwtConstants = {
  secret: 'kira2677',
};
