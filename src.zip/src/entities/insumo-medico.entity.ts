// insumo.entity.ts
import { Entity, Column } from 'typeorm';
import { ProductoMedico } from './producto-medico.entity';

@Entity()
export class Insumo extends ProductoMedico {
  @Column()
  tipo: string;
  @Column()
  material: string;
  @Column()
  instruccionesUso: string;
}
