// medicamento.entity.ts
import { Column, Entity } from 'typeorm';
import { ProductoMedico } from './producto-medico.entity';

@Entity()
export class Medicamento extends ProductoMedico {
  @Column()
  composicion: string;

  @Column()
  laboratorio: string;

  @Column()
  nombreComercial: string;
}
