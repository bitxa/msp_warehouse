// producto-medico.entity.ts
import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  OneToOne,
  TableInheritance,
} from 'typeorm';
import { Inventario } from './inventario.entity';

@Entity()
@TableInheritance({ column: { type: 'varchar', name: 'type' } })
export class ProductoMedico {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  nombre: string;

  @Column()
  fechaFabricacion: string;

  @Column()
  fechaCaducidad: string;

  @Column()
  cantidadExistencias: number;

  @Column()
  descripcion: string;

  @Column()
  fabricante: string;

  @Column({ type: 'double precision' })
  precio: number;

  @OneToOne(() => Inventario, (inventario) => inventario.productoMedico)
  inventario: Inventario;
}
