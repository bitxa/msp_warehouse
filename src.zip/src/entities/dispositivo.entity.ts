// dispositivo.entity.ts
import { Entity, Column } from 'typeorm';
import { ProductoMedico } from './producto-medico.entity';

@Entity()
export class Dispositivo extends ProductoMedico {
  @Column()
  serieFabrica: number;
  @Column()
  vidaUtil: number;
  @Column()
  indicaciones: string;
  @Column()
  tipo: string;
}
