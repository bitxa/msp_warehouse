// producto-medico.entity.ts
import {
  Column,
  Entity,
  ManyToOne,
  OneToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { Administrador } from './administrador.entity';
import { Medicamento } from './medicamento.entity';

@Entity()
export class Inventario {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  fechaFabricacion: string;

  @Column()
  fechaCaducidad: string;

  @Column()
  ubicacion: string;
  @Column()
  cantidad: number;

  @ManyToOne(() => Administrador, (administrador) => administrador.inventarios)
  administrador: Administrador;

  @OneToOne(() => Medicamento, (productoMedico) => productoMedico.inventario, {
    cascade: true,
  })
  productoMedico: Medicamento;
}
