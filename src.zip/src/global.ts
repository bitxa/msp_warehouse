import { Global, Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Medicamento } from '@entities/medicamento.entity';
import { Inventario } from '@entities/inventario.entity';
import { Dispositivo } from '@entities/dispositivo.entity';
import { Insumo } from '@entities/insumo-medico.entity';
import { ProductoMedico } from '@entities/producto-medico.entity';
// ... other entities

@Global()
@Module({
  imports: [
    TypeOrmModule.forFeature([
      Medicamento,
      Inventario,
      ProductoMedico,
      Insumo,
      Dispositivo,
      Medicamento,
      Inventario,
    ]),
  ],
  exports: [TypeOrmModule],
})
export class DatabaseModule {}
