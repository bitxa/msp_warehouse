import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { ProductoMedico } from '@entities/producto-medico.entity';
import { Inventario } from '@entities/inventario.entity';
import { InventarioService } from '@features/inventario/inventario.service';
import { Like, Repository } from 'typeorm';
import { Medicamento } from '@entities/medicamento.entity';
import { Insumo } from '@entities/insumo-medico.entity';
import { Dispositivo } from '@entities/dispositivo.entity';

@Injectable()
export class AdministradorService {
  @InjectRepository(Medicamento)
  private medicamentoRepository: Repository<Medicamento>;
  @InjectRepository(Insumo)
  private insumoRepository: Repository<Medicamento>;
  @InjectRepository(Dispositivo)
  private dispositivoRepository: Repository<Dispositivo>;

  constructor(private inventarioService: InventarioService) {}

  async consultarDetallesProducto(
    nombreProducto: string,
  ): Promise<ProductoMedico[]> {
    const medicamentos = await this.medicamentoRepository.find({
      where: { nombre: Like(`%${nombreProducto}%`) },
    });
    const insumos = await this.insumoRepository.find({
      where: { nombre: Like(`%${nombreProducto}%`) },
    });
    const dispositivos = await this.dispositivoRepository.find({
      where: { nombre: Like(`%${nombreProducto}%`) },
    });

    return [...medicamentos, ...insumos, ...dispositivos];
  }

  async registrarProductoMedico(
    fechaCaducidad: string,
    fechaFabricacion: string,
    ubicacion: string,
    cantidadProductos: number,
    administradorId: number,
    productoMedicoId: number,
  ): Promise<Inventario> {
    console.log('aaa');

    const nuevoInventario =
      await this.inventarioService.createAndSaveInventario({
        fechaCaducidad,
        fechaFabricacion,
        ubicacion,
        cantidadProductos,
        administradorId,
        productoMedicoId,
      });

    console.log(nuevoInventario);

    await this.inventarioService.actualizarExistencias(nuevoInventario.id);

    return nuevoInventario;
  }
}
