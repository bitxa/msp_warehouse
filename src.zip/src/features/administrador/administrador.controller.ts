import { Controller, Get, Post, Body, Param } from '@nestjs/common';
import { AdministradorService } from './administrador.service';
import { ProductoMedico } from '@entities/producto-medico.entity';
import { Inventario } from '@entities/inventario.entity';

@Controller('administrador')
export class AdministradorController {
  constructor(private readonly administradorService: AdministradorService) {}

  @Get('/producto/:nombreProducto')
  async consultarDetallesProducto(
    @Param('nombreProducto') nombreProducto: string,
  ): Promise<ProductoMedico[]> {
    console.log('querying producto');
    return await this.administradorService.consultarDetallesProducto(
      nombreProducto,
    );
  }

  @Post('/producto')
  async registrarProductoMedico(
    @Body()
    createProductoDto: {
      fechaCaducidad: string;
      fechaFabricacion: string;
      ubicacion: string;
      cantidadProductos: number;
      administradorId: number;
      productoMedicoId: number;
    },
  ): Promise<Inventario> {
    return await this.administradorService.registrarProductoMedico(
      createProductoDto.fechaCaducidad,
      createProductoDto.fechaFabricacion,
      createProductoDto.ubicacion,
      createProductoDto.cantidadProductos,
      createProductoDto.administradorId,
      createProductoDto.productoMedicoId,
    );
  }
}
