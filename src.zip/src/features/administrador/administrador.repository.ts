// administrador.repository.ts
import { Repository } from 'typeorm';
import { Administrador } from '@entities/administrador.entity';

export class AdministradorRepository extends Repository<Administrador> {}
