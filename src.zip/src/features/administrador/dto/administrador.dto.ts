import { IsNumber, IsEmpty } from 'class-validator';

export class AdministradorDto {
  @IsNumber()
  @IsEmpty()
  experiencia: string;
}
