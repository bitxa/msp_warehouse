// administrador.repository.ts
import { Repository } from 'typeorm';
import { ProductoMedico } from '@entities/producto-medico.entity';

export class ProductoMedicoRepository extends Repository<ProductoMedico> {}
