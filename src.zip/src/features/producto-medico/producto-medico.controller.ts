/* eslint-disable @typescript-eslint/no-unused-vars */
import { Controller, Get, Post, Body, Param } from '@nestjs/common';
import { ProductoMedicoService } from './producto-medico.service';
import { ProductoMedico } from '@entities/producto-medico.entity';
import { Inventario } from '@entities/inventario.entity';

@Controller('administrador')
export class ProductoMedicoController {}
