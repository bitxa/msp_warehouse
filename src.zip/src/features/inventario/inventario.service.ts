/* eslint-disable @typescript-eslint/no-unused-vars */
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { EntityManager, FindOptionsWhere, Repository } from 'typeorm';
import { Inventario } from '@entities/inventario.entity';
import { Dispositivo } from '@entities/dispositivo.entity';
import { Medicamento } from '@entities/medicamento.entity';
import { Insumo } from '@entities/insumo-medico.entity';

@Injectable()
export class InventarioService {
  constructor(
    @InjectRepository(Inventario)
    private inventarioRepository: Repository<Inventario>,

    @InjectRepository(Dispositivo)
    private dispositivoRepository: Repository<Dispositivo>,

    @InjectRepository(Medicamento)
    private medicamentoRepository: Repository<Medicamento>,

    @InjectRepository(Insumo)
    private insumoRepository: Repository<Insumo>,

    private readonly entityManager: EntityManager,
  ) {}

  private async tryUpdateEntity<T extends { id: number }>(
    tableName: string,
    id: number,
    updatedStock: number,
  ): Promise<void> {
    try {
      console.log('UPDATING');

      const query = `
        UPDATE ${tableName}
        SET cantidadExistencias = $1
        WHERE id = $2
      `;

      await this.entityManager.query(query, [updatedStock, id]);
    } catch (error) {
      console.error('Error in tryUpdateEntity:', error);
      throw error; // Re-throw the error to be caught by the caller
    }
  }

  async actualizarExistencias(inventarioId: number): Promise<void> {
    const inventario = await this.inventarioRepository.findOne({
      where: { id: inventarioId },
    });

    if (!inventario) {
      throw new Error('Inventario not found');
    }

    const updatedStock = inventario.cantidad;

    // Try updating as Dispositivo
    await this.tryUpdateEntity(
      'dispositivo',
      inventario.productoMedico.id,
      updatedStock,
    );

    // Try updating as Medicamento
    await this.tryUpdateEntity(
      'medicamento',
      inventario.productoMedico.id,
      updatedStock,
    );

    // Try updating as Insumo
    await this.tryUpdateEntity(
      'insumo',
      inventario.productoMedico.id,
      updatedStock,
    );
  }

  async createAndSaveInventario(data: {
    fechaCaducidad: string;
    fechaFabricacion: string;
    ubicacion: string;
    cantidadProductos: number;
    administradorId: number;
    productoMedicoId: number;
  }): Promise<Inventario> {
    console.log(`${data.fechaCaducidad}`);
    const nuevoInventario = this.inventarioRepository.create({
      fechaCaducidad: data.fechaCaducidad,
      fechaFabricacion: data.fechaFabricacion,
      ubicacion: data.ubicacion,
      cantidad: data.cantidadProductos,
      administrador: { id: data.administradorId },
      productoMedico: { id: data.productoMedicoId },
    });

    console.log(nuevoInventario);
    console.log('created');
    return await this.inventarioRepository.save(nuevoInventario);
  }
}
