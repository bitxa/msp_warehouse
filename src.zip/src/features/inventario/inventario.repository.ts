// administrador.repository.ts
import { Repository } from 'typeorm';
import { Inventario } from '@entities/inventario.entity';

export class InventarioRepository extends Repository<Inventario> {}
