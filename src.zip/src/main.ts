/* eslint-disable @typescript-eslint/no-unused-vars */
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { AppDataSource } from './config/typeorm';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  await app.listen(3000);

  try {
    await AppDataSource.initialize();
    console.log('Data Source has been initialized!');

    await AppDataSource.runMigrations();
    console.log('Migrations executed');
  } catch (err) {
    console.error(
      'Error during Data Source initialization or migrations:',
      err,
    );
    process.exit(1);
  }

  console.log(`La aplicación está corriendo en: ${await app.getUrl()}`);
}

bootstrap();
